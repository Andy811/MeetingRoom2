package cathay.hospital.example.util;

public class UtilCommonVariable {
    public static String connectEnv = "test";//001 or test
    public static int allowStoragePermission = 4;
}
